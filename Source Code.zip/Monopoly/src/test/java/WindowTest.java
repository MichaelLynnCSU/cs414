import org.junit.Test;

import static org.junit.Assert.*;

public class WindowTest extends BaseTest{

    Controller controller = new Controller("");
    Window window = new Window(controller);

    @Test
    public void testJailedOptioms() {
    }
}