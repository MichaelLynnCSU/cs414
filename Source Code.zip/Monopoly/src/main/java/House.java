public class House extends PropertyImprovement {
}
