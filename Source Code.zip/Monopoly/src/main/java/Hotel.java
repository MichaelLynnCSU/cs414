public class Hotel extends PropertyImprovement {
}
