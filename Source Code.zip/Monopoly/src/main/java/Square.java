//Basic square class
public class Square {
	String name;
	
	public Square(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public void doAction(Player p, MonopolyBoard board, Controller controller){
		return;
	}

}
